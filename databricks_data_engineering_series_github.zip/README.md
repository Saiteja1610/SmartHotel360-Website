# Databricks Data Engineering Series

This repository contains a complete end-to-end learning path for mastering Data Engineering on Databricks.

## 📦 Structure
- `notebooks/`: Lessons and exercises.
- `dlt_pipeline/`: Delta Live Tables pipeline script.
- `streaming_pipeline/`: Structured Streaming with Auto Loader.
- `configs/`: Secrets config template.

## 🚀 Topics Covered
- Lakehouse Architecture
- Delta Lake
- Incremental ETL
- Delta Live Tables (DLT)
- Structured Streaming
- Unity Catalog
- Data Validation & CI/CD

Each module can be used standalone or as part of the final Retail Sales Analytics Project.

## ✅ Setup Instructions
1. Clone the repo.
2. Import notebooks to your Databricks workspace.
3. Configure DLT and Streaming pipelines.
4. Run step-by-step using the guides in each notebook.
