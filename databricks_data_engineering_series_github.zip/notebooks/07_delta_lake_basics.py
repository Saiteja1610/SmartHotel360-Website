# 07 Delta Lake Basics
